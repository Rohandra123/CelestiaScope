from astropy.io import fits
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colors

# Path to the folder
file_path = r'C:\Users\bkmfu\OneDrive\Documents\CelestiaScope'

# Open the FITS file (specify the filename)
fits_file = r'C:\Users\bkmfu\OneDrive\Documents\CelestiaScope\blue.fits'
fits_data = fits.open(fits_file)

# Print information about the FITS file
fits_data.info()

#Extract image data from the FITS file
image_data = fits_data[0].data

header = fits_data[0].header
print(repr(header))

# Normalize the image data to the range 0-1
image_data = image_data - np.min(image_data)
image_data = image_data / np.max(image_data)

gamma = 0.3
image_data = np.power(image_data, gamma)

#Plot the image data
# Create a custom colormap from black to white
cmap = colors.LinearSegmentedColormap.from_list("black_white_yellow_blue", ["black", "white","yellow","blue"])

# Display with custom colormap
plt.imshow(image_data, cmap=cmap, origin='lower')
plt.colorbar()
plt.title('Astronomical Image')
plt.show()


#Close the FITS file
fits_data.close()